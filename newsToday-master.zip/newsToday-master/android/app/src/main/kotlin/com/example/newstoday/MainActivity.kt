package com.example.newstoday

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

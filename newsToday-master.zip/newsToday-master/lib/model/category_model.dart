class CategoryModel {
  String categoryName;
  String imageURL;

  CategoryModel({this.categoryName, this.imageURL});
}
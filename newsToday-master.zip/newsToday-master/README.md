# News Today

A new News Today app built on flutter

## Getting Started

### To run-
#### flutter pub get

#### flutter run


This app is powered by NewsApi.org
If news not dispalyed you've to use your own api can be generated from newsapi.org for free

Go to lib/helper/news.dart

http://newsapi.org/v2/top-headlines?country=in&apiKey={replace with API Key without "{}" parenthesis}";

### Show some :heart: and star the repo to support the project
#### Screenshots

![](https://github.com/sauravgpt/newsToday/blob/master/screenshots/Screenshot_1.png)
![](https://github.com/sauravgpt/newsToday/blob/master/screenshots/Screenshot_2.png)
![](https://github.com/sauravgpt/newsToday/blob/master/screenshots/Screenshot_3.jpg)
